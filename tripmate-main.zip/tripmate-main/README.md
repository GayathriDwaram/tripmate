# TripMate

## Installation

To install the project, run the following command:

```bash
npm i
```

Running the Project
To start the project, run the following command:

```bash
npm run dev
```
